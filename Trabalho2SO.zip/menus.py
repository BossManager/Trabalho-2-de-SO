def menu_Usuario():#pronto
	print('Usuario:')
	print('[1] Aluno')
	print('[2] Administrador')

def menu_Aluno():#pronto
	print('Menu Aluno:')
	print('[1] Pedido')
	print('[2] Liberacao')		

def menu_Admin():#pronto
	print('Menu Administrador:')
	print('[1] Numero de exemplares (totais)')
	print('[2] Numero de exemplares (com aluno)')
	print('[3] Alunos em espera')
#########################################################################
## Author: Daniel Nogueira de Oliveira, matricula 385386               ##
## Version: 0.3(final)                                                 ##
## status: 100%                                                        ##
#########################################################################