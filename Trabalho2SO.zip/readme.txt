Comando para executar o programa: python3 biblioteca.py
